-- phpMyAdmin SQL Dump
-- version 3.3.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 18, 2011 at 09:49 AM
-- Server version: 5.1.54
-- PHP Version: 5.3.5-1ubuntu7.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `Simple`
--

-- --------------------------------------------------------

--
-- Table structure for table `Curso`
--

CREATE TABLE IF NOT EXISTS `Curso` (
  `numeroExpediente` int(11) NOT NULL,
  `nombreCurso` varchar(50) COLLATE ucs2_spanish2_ci NOT NULL,
  `fechaComienzo` date NOT NULL,
  `horas` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish2_ci;

--
-- Dumping data for table `Curso`
--

INSERT INTO `Curso` (`numeroExpediente`, `nombreCurso`, `fechaComienzo`, `horas`) VALUES
(1, 'PAI', '2011-04-28', 975),
(2, 'HTML', '2010-01-01', 100),
(9, 'UML', '2011-02-10', 200),
(9, 'UML', '2011-02-10', 200);

-- --------------------------------------------------------

--
-- Table structure for table `Evaluacion`
--

CREATE TABLE IF NOT EXISTS `Evaluacion` (
  `numExpedienteCurso` int(11) NOT NULL,
  `dniPersona` int(11) NOT NULL,
  `puntuacion` float NOT NULL,
  `fecha` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish2_ci;

--
-- Dumping data for table `Evaluacion`
--

INSERT INTO `Evaluacion` (`numExpedienteCurso`, `dniPersona`, `puntuacion`, `fecha`) VALUES
(1, 1, 10, '2011-11-16'),
(2, 2, 7.5, '2011-02-01');

-- --------------------------------------------------------

--
-- Table structure for table `Persona`
--

CREATE TABLE IF NOT EXISTS `Persona` (
  `dni` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE ucs2_spanish2_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish2_ci;

--
-- Dumping data for table `Persona`
--

INSERT INTO `Persona` (`dni`, `nombre`) VALUES
(1, 'Nombre1'),
(2, 'Nombre2');

-- --------------------------------------------------------

--
-- Table structure for table `Tabla1`
--

CREATE TABLE IF NOT EXISTS `Tabla1` (
  `campoEntero` int(11) NOT NULL,
  `campoTexto` varchar(50) COLLATE ucs2_spanish2_ci NOT NULL,
  `campoFloat` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish2_ci;

--
-- Dumping data for table `Tabla1`
--

INSERT INTO `Tabla1` (`campoEntero`, `campoTexto`, `campoFloat`) VALUES
(1, 'Texto1', 1.1),
(2, 'Texto 2', 2.2);
